package finalcodeguianddb;

/**
 *
 * @author kevfro
 */
public class installDBR
{
    public static void main(String[] args)
    {
        String dbName = "numbersStoredforRlatest";
        JavaDB objDb = new JavaDB();
        objDb.createDb(dbName);
        
        String newTable = "CREATE TABLE storedThingforRLatest (num1 varchar(50), "
            + "num1Position varchar(50), num2 varchar(50), num2position varchar(50), R varchar(50))";
        
        objDb.createTable(newTable, dbName);
        
    }
}

