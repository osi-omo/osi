package finalcodeguianddb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class insertDB {
  private String make;
  private int price;
  private String color;

  public insertDB(String make, int price, String color) {
    this.make = make;
    this.price = price;
    this.color = color;
  }

  public void insert() {
    String dbName = "numbers";
      String tableName = "items";
      String[] columnNames = 
      {
        "numberS", "numberR", "numberA1", "numberN"
      };
      JavaDB objDb = new JavaDB(dbName);
      Connection myDbConn = objDb.getDbConn();

      String dbQuery = "INSERT INTO items VALUES(?,?,?,?)";
      
    try {
      PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
      ps.setString(1, make);
      ps.setInt(2, price);
      ps.setString(3, color);

      ps.executeUpdate();
      System.out.println("Data inserted successfully");
      
    } 
    catch (NumberFormatException nfe)
      {
        System.out.println("Enter digits for price");
      }
      catch (SQLException se)
      {
        System.out.println("Error inserting data");
      }
    
  }
  public static void main(String[] args)
  {
    String dbName = "table";
      String tableName = "values";
      String[] columnNames = 
      {
        "number S","number R","number A1","number N","result"
      };
    insertDB newah = new insertDB("me", 0, "hi");
    DisplayDB objDisplay = new DisplayDB(dbName, tableName, columnNames);
    
  }
}