package finalcodeguianddb;
import java.sql.Connection;
import java.util.ArrayList;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

/**
 * @author mohsenmirza
 *
 */
public class JavaDBR
{
  private String dbName;
  private Connection dbConn;
  private ArrayList<ArrayList<String>> data;
  public JavaDBR()
  {
    this.dbName = "";
    this.dbConn = null;
    this.data = null;
  }
  public JavaDBR(String dbName)
  {
    setDbName(dbName);
    setDbConn();
    this.data = null;
  }
  public String getDbName()
  {
    return dbName;
  }
  public void setDbName(String dbName)
  {
    this.dbName = dbName;
  }
  public Connection getDbConn()
  {
    return dbConn;
  }
  public void setDbConn()
  {
    //mysql connection
    String connectionURL = "jdbc:mysql://localhost:3306/" + this.dbName;
    this.dbConn = null;
    try
    {
      Class.forName("com.mysql.cj.jdbc.Driver");//checking if driver in library
      this.dbConn = DriverManager.getConnection(connectionURL, "root", "mysql1");//end of mysql connection
    }
    catch (ClassNotFoundException ex)
    {
      System.out.println("Driver not found, check library");
    }
    catch (SQLException se)
    {
      System.out.println("SQL Connection error, Db was not created!" + se.getMessage());
    }
  }
  public ArrayList<ArrayList<String>> getData(String tableName, String[] tableHeaders)
  {
    int columnCount = tableHeaders.length;
    Statement s = null;
    ResultSet rs = null;
    String dbQuery = "SELECT * FROM " + tableName;
    this.data = new ArrayList<>();
    //read the data
    try
    {
      //send the query and recieve data to rs pointer
      s = this.dbConn.createStatement();
      rs = s.executeQuery(dbQuery);
      //read the data using rs and store in ArrayList data
      while (rs.next())
      {
//row object to hold one row data
        ArrayList<String> row = new ArrayList<>();
        //go through the row and read each cell
        for (int i = 0; i < columnCount; i++)
        {
          //read cell i
          //example: String cell = rs.getString("Make");
          //reads the cell in column Make
          //tableHeaders = {"Make","Price", "Color"}
          String cell = rs.getString(tableHeaders[i]);
          //add the cell to the row
          //example row.add("Ford");
          row.add(cell);
        }
        //add the row to the date
        //example: data.add "Ford", 15000, "Pink"
        this.data.add(row);
      }
    }
    catch (SQLException se)
    {
      System.out.println("SQL Ezrror: Not able to get data" + se.getMessage());
    }
    return data;
  }
  public void setData(ArrayList<ArrayList<String>> data)
  {
    this.data = data;
  }
  public void createDb(String newDbName)
  {
    setDbName(newDbName);
    Connection newConn;
    //mysql connection
    String connectionURL = "jdbc:mysql://localhost:3306/";
    String query = "CREATE DATABASE " + this.dbName;
    try
    {
      Class.forName("com.mysql.cj.jdbc.Driver");
      newConn = DriverManager.getConnection(connectionURL, "root", "mysql1");
      Statement s = newConn.createStatement();
      s.executeUpdate(query);
      System.out.println("New database created.");
      newConn.close();
      //end of mysql connection
    }
    catch (ClassNotFoundException ex)
    {
      System.out.println("Driver not found, check library");
    }
    catch (SQLException se)
    {
      System.out.println("SQL Connection error, Db was not created");
    }
  }
  public void createTable(String newTable, String dbName)
  {
    System.out.println(newTable);
    setDbName(dbName);
    setDbConn();
    Statement s;
    try
    {
      s = this.dbConn.createStatement();
      s.execute(newTable);
      System.out.println("New table created.");
      this.dbConn.close();
    }
    catch (SQLException err)
    {
      System.out.println("Error creating table " + newTable);
    }
  }
  public void closeDbConn()
  {
    try
    {
      this.dbConn.close();
    }
    catch (Exception err)
    {
      System.out.println("Db closing error");
    }
  }
  public Object[][] to2dArray(ArrayList<ArrayList<String>> data)
  {
    if (data.size() == 0)
    {
      Object[][] dataList = new Object[0][0];
      return dataList;
    }
    else
    {
      int columnCount = data.get(0).size();
      //2d array [row][column]
      Object[][] dataList = new Object[data.size()][columnCount];
      for (int r = 0; r < data.size(); r++)
      {
        ArrayList<String> row = data.get(r);
        for (int c = 0; c < columnCount; c++)
        {
          dataList[r][c] = row.get(c);
        }
      }
      return dataList;
    }
  }
  public static void main(String[] args)
  {
    /*
     * First Part: How to inset data
     */
    // db info
    String dbName = "numbersStoredforRlatest";
      String tableName = "storedThingforRLatest";
      String[] columnNames =
      {
        "num1", "num1Position", "num2", "num2position", "R"
      };
    //insert query
    String dbQuery = "INSERT INTO storedThingforRLatest VALUES (?,?,?,?,?)";
    //connect to db
    JavaDB objDb = new JavaDB(dbName);
    Connection myDbConn = objDb.getDbConn();
    // to be read from text field in GUI programs
    //for now we have manually assigned values
    String readName = "hi";
    String readPrice = "me";
    String readColor = "osi";
    String readlast = "for";
    String readmy = "play";
    //insert into Database
    try
    {
      //prepare statement
      PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
      //enter data into query
      ps.setString(1, readName);
      ps.setString(2, readPrice);
      ps.setString(3, readColor);
      ps.setString(4, readlast);
      ps.setString(5, readmy);
      //execute the query
      ps.executeUpdate();
      System.out.println("Data inserted successfully");
    }
    catch (SQLException se)
    {
      System.out.println("Error inserting data");
    }
    /*
     * ******************************************
    *
    * Second Part: how to read and display data
    *
    *********************************************
     */
    //reading data from DB into a 2d arrayList
    ArrayList<ArrayList<String>> data = objDb.getData(tableName, columnNames);
    // displaying the 2d arraylist
    System.out.println(data);
    /*
     * Third part: testing to2dArray method
     */
    //convert 2d arraylist to 2d array
    Object[][] data2d = objDb.to2dArray(data);
    // displaying the 2d array
    for (int r = 0; r < data2d.length; r++)
    {
      for (int c = 0; c < data2d[0].length; c++)
      {
        System.out.print(data2d[r][c] + " ");
      }
      System.out.println();
    }
  }
}

