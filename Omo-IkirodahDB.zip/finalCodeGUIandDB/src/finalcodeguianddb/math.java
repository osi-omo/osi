/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalcodeguianddb;

import java.lang.Math;

/**
 *
 * @author osiom
 */
public class math
{

  private double numberR;
  private double numberN;
  private double numberA1;
  private double numberS;
  private String result;

  public math(double n1, double n2, double n3, double n4)
  {
    numberR = n1;
    numberN = n2;
    numberA1 = n3;
    numberS = n4;

  }

  public String SolveS()
  {

    double bottom = 1 - this.numberR;
    double rInit = this.numberR;
    for (int i = 1; i < this.numberN; i++)
    {
      this.numberR = this.numberR * rInit;
    }
    double ans = (this.numberA1 * (1 - this.numberR)) / bottom;
    if (this.numberR == 1)
    {
      this.result = "r cant be 1";
    }
    else
    {
      this.result = Double.toString(ans);
    }

    return result;
  }

  public String SolveA1()
  {
    double bottom = 1 - this.numberR;
    double rInit = this.numberR;
    for (int i = 1; i < this.numberN; i++)
    {
      this.numberR = this.numberR * rInit;
    }

    double ans = (this.numberS * bottom) / (1 - this.numberR);
    if (this.numberR == 1)
    {
      this.result = "r cant be 1";
    }
    else
    {
      this.result = Double.toString(ans);
    }

    return result;
  }

  public String SolveN()
  {
    double r = this.numberR;
    double logged = -1 * ((this.numberS * (1 - this.numberR) / this.numberA1) - 1);
    double loggedin = logged;
    if (this.numberR < 0)
    {
      r = r * -1;
    }
    if (logged < 0)
    {
      loggedin = loggedin * -1;
    }
    double ans = Math.log(loggedin) / Math.log(r);
    if (this.numberR == 1 && this.numberA1 == 0)
    {
      this.result = "r cant be 1 while a1 is 0";
    }
    else if (ans % 1 > 0)
    {
      this.result = "your answer is a decimal";
    }
    else if ( this.numberR == 1 && this.numberS != this.numberA1){
      this.result = "your answer is nan";
    }
    else
    {
      this.result = Double.toString(ans);
    }
    return result;
  }

  public String SolveR()
  {
    double num1 = numberR;
    double num1place = numberA1;
    double num2 = numberN;
    double num2place = numberS;
    double place = num2place - num1place;
    double numrooted = num2 / num1;
    double ans;

    ans = Math.pow(numrooted, 1 / place);
    ans = ans * -1;
    if (num2place == 0 || num1place == 0){
      this.result = "ÿour equation is illogical";
    }
    else if (num1 == 0 && num2 > 0)
    {
      this.result = "ÿour equation is illogical";
    }
    else if (num2 < 0 && num1 == 0)
    {
      this.result = "ÿour equation is illogical";
    }
    else if (num2 == 0 && num1 > 0 )
    {
      this.result = "ÿour equation is illogical";
    }
    else if (num1 < 0 && num2 == 0)
    {
      this.result = "ÿour equation is illogical";
    }
    else if (num1 > 0 && num2 < 0 && place % 2 == 0)
    {
      this.result = "ÿour equation is illogical";
    }
    else if (num1 < 0 && num2 > 0 && place % 2 == 0)
    {
      this.result = "ÿour equation is illogical";
    }
    else if (num1 < 0 && num2 < 0){
      this.result = Double.toString(ans * -1);
    }
    else if (num1 > 0 && num2 > 0){
      this.result = Double.toString(ans * -1);
    }
    else if (num1 > 0 && num2 < 0 && place % 2 == 1)
    {
      ans = ans * -1;
      this.result = Double.toString(ans);
    }
    else if (num1 < 0 && num2 > 0 && place % 2 == 1)
    {
      ans = ans * -1;
      this.result = Double.toString(ans);
    }
    else{
      this.result = Double.toString(ans);
    }
    return result;
  }
  
  public String getr(){
    this.result = result;
    return result;
  }

}
