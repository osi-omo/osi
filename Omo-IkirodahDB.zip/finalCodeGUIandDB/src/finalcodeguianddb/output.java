/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalcodeguianddb;

import static finalcodeguianddb.choice.BIG__FONT;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author osiom
 */
public class output extends JFrame implements ActionListener
{

  public static final Color gray = new Color(90, 0, 4);
  public static final Color idk = new Color(67, 90, 0);

  private final URL WELCOME_PATH = getClass().getResource("goodLuck.jpg");
  private final ImageIcon IMAGE = new ImageIcon(new ImageIcon(WELCOME_PATH).getImage().getScaledInstance(630, 420,Image.SCALE_DEFAULT));
  
  private JLabel resultLabel;
  private JLabel resultLabel2;
  private JLabel binary;
  private JLabel converge;
  private JLabel graph;
  private JLabel trys;
  private JLabel imageLabel;
  private JPanel resultPanel;

  private JButton okay;
  private JButton back;
  private JButton restart;
  private JButton data;
  private JPanel buttonPanel;

  private JLabel imageB;
  private JLabel imageC;
  private JLabel imageG;
  private JLabel imageT;
  private JPanel imagePanelTop;
  private JPanel imagePanelBottom;
  private JPanel namesTop;
  private JPanel namesbottom;

  public final Font hi = new Font("Lobster", Font.BOLD, 20);
  private static String result;
  private static int determiner;

  
  public output(String result, int determiner)
  {
    super("Output");
    this.result = result;
    this.determiner = determiner;
    this.setBounds(500, 500, 700, 600);

    this.imageLabel = new JLabel(IMAGE);
    imageLabel.setBorder(BorderFactory.createEmptyBorder(10,10,0,50));
    
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.getContentPane().setBackground(idk);

    resultLabel = new JLabel("your result is " + result, SwingConstants.CENTER);
    resultLabel.setFont(hi);
    resultLabel.setForeground(gray);
    resultPanel = new JPanel();
    resultPanel.add(resultLabel);
    resultPanel.add(Box.createVerticalStrut(60));
    resultPanel.setLayout(new BoxLayout(resultPanel, BoxLayout.Y_AXIS));

    okay = new JButton("OK");
    okay.addActionListener(this);
    back = new JButton("back");
    back.addActionListener(this);
    restart = new JButton("restart");
    restart.addActionListener(this);
    data = new JButton("view data");
    data.addActionListener(this);

    buttonPanel = new JPanel();
    buttonPanel.add(okay);
    buttonPanel.add(back);
    buttonPanel.add(restart);

    this.add(resultPanel, BorderLayout.NORTH);
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.add(imageLabel, BorderLayout.CENTER);

    this.setVisible(true);
  }

  public void actionPerformed(ActionEvent e)
  {
    String command = e.getActionCommand();
    if (command.equals("OK"))
    {
      this.dispose();

    }
    else if (command.equals("back"))
    {
      this.dispose();
      if (this.determiner == 1)
      {
        new inputForN();
      }
      else if (this.determiner == 3)
      {
        new inputForS();
      }
      else if (this.determiner == 4)
      {
        new inputForR();
      }
      else if (this.determiner == 2)
      {
        new inputForA1();
      }
    }
    else if (command.equals("restart"))
    {
      this.dispose();
      new FiniteGeoSeq();
    }
    else if (command.equals("view data")){
      String dbName = "numbers";
      String tableName = "items";
      String[] columnNames = 
      {
        "number S","number R","number A1","number N"
      };
    }
  }
  public static void main(String[] args)
  {
    
  }
}
