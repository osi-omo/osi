/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalcodeguianddb;

//imports
import static finalcodeguianddb.choice.BLUE__COLOR;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

//main code 
public class inputForN extends JFrame implements ActionListener
{

  public static final Color Turqoise = new Color(9, 203, 184);
  public static final Color idk = new Color(254, 190, 2);
  public static final Font CAPTION_FONT = new Font("Pacifico", Font.BOLD, 15);
  public final Font INSTUCTIONS_FONT = new Font("Pacifico", Font.BOLD, 20);
  public static final Color PURPLE = new Color(9, 203, 184);

  private final URL WELCOME_PATH = getClass().getResource("nimage.jpg");
  private final ImageIcon IMAGE = new ImageIcon(new ImageIcon(WELCOME_PATH).getImage().getScaledInstance(600, 400, Image.SCALE_DEFAULT));

  private JLabel numberLabelS;
  private JLabel numberLabelR;
  private JLabel numberLabelA1;
  private JLabel instructions;

  private JTextField numberFieldR;
  private JTextField numberFieldS;
  private JTextField numberFieldA1;

  private JButton enter;
  private JButton back;
  private JButton home;
  private JButton data;
  private JLabel imageLabel;
  private JPanel inputPanel;
  private JPanel buttonPanel;

  public inputForN()
  {
    super("Welcome Frame");
    this.setBounds(100, 50, 800, 600);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.getContentPane().setBackground(BLUE__COLOR);

    this.imageLabel = new JLabel(IMAGE);
    imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 50));

    instructions = new JLabel("Please enter your values: ", SwingConstants.CENTER);
    instructions.setFont(INSTUCTIONS_FONT);
    numberLabelR = new JLabel("r: ");
    instructions.setFont(CAPTION_FONT);
    numberLabelS = new JLabel("S: ");
    numberLabelS.setFont(CAPTION_FONT);
    numberLabelA1 = new JLabel("A1: ");
    numberLabelA1.setFont(CAPTION_FONT);

    //the character limit affects text feild size
    numberFieldR = new JTextField(10);
    numberFieldS = new JTextField(10);
    numberFieldA1 = new JTextField(10);

    enter = new JButton("enter");
    enter.addActionListener(this);
    back = new JButton("back");
    back.addActionListener(this);
    home = new JButton("home");
    home.addActionListener(this);
    data = new JButton("data");
    data.addActionListener(this);

    buttonPanel = new JPanel();
    buttonPanel.add(back);
    buttonPanel.add(home);
    buttonPanel.add(data);
    buttonPanel.setBackground(idk);

    //the order in wich you add to a container is the order inwhich components appear
    inputPanel = new JPanel();
    inputPanel.add(Box.createVerticalStrut(80));
    inputPanel.add(numberLabelR);
    inputPanel.add(numberFieldR);
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(numberLabelS);
    inputPanel.add(numberFieldS);
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(numberLabelA1);
    inputPanel.add(numberFieldA1);
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(enter);
    inputPanel.add(Box.createVerticalStrut(80));
    inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
    inputPanel.setBackground(Turqoise);

    this.add(instructions, BorderLayout.NORTH);
    this.add(inputPanel, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.add(imageLabel, BorderLayout.WEST);

    this.setVisible(true);
  }

  public static void main(String[] args)
  {
    new inputForN();
  }

  public void actionPerformed(ActionEvent e)
  {
    String command = e.getActionCommand();

    String result;

    if (command.equals("back"))
    {
      this.dispose();
      new choice();
    }

    else if (command.equals("home"))
    {
      this.dispose();
      new FiniteGeoSeq();
    }

    else if (command.equals("data"))
    {
      String dbName = "numbers";
      String tableName = "items";
      String[] columnNames = 
      {
        "numberS", "numberR", "numberA1", "numberN"
      };
      new DisplayDB(dbName, tableName, columnNames);
    }

    else if (command.equals("enter")){
      this.dispose();
      
      command = e.getActionCommand();
      String dbName = "numbers";
      String tableName = "items";
      String[] columnNames = 
      {
        "numberS", "numberR", "numberA1", "numberN"
      };
      JavaDB objDb = new JavaDB(dbName);
      Connection myDbConn = objDb.getDbConn();

      String dbQuery = "INSERT INTO items VALUES(?,?,?,?)";
      double numberS;
      double numberR;
      double numberA1; 
      double numberN = 0; 
      
      try
      {
        numberS = Double.parseDouble(numberFieldS.getText());
        numberR = Double.parseDouble(numberFieldR.getText());
        numberA1 = Double.parseDouble(numberFieldA1.getText());
        math objectadd = new math(numberR, numberN,numberA1,0);
        result = objectadd.SolveS();
        
        
        PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
        ps.setDouble(1,numberS);
        ps.setDouble(2,numberR);
        ps.setDouble(3,numberA1);
        ps.setDouble(4,Double.parseDouble(result));
      
        ps.executeUpdate();
        System.out.println("Data inserted succesfully");
        
        
        this.toFront();
      }
      catch (NumberFormatException nfe)
      {
        System.out.println("Enter digits for price");
      }
      catch (SQLException se)
      {
        System.out.println("Error inserting data");
      }
      
      try
      {
        numberS = Double.parseDouble(numberFieldS.getText());
        numberR = Double.parseDouble(numberFieldR.getText());
        numberA1 = Double.parseDouble(numberFieldA1.getText());
        math objectadd = new math(numberR, 0,numberA1,numberS);
        result = objectadd.SolveN();
        if (result.equalsIgnoreCase("r cant be 1 while a1 is 0")){
          this.dispose( );
          new error("r cant be 1 while a1 is 0",1);
        }
        else if (result.equalsIgnoreCase("your answer is a decimal")){
          new error("your answer is a decimal",1);
        }   
        else if (result.equalsIgnoreCase("your answer is nan")){
          new error("your answer is non existent",1);
        }   
        else{
          new output(result,1);

        }
        
      }
      catch (NumberFormatException lol)
      {
        //lol.getStackTrace();//returns exception stack trace
        //System.exit(0);
        //inform the user
        new warning("please enter only numbers twin",1);
      }

    }
  }
}

