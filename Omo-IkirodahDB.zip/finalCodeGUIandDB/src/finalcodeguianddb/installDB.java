package finalcodeguianddb;

/**
 *
 * @author kevfro
 */
public class installDB
{
    public static void main(String[] args)
    {
        String dbName = "numbers";
        JavaDB objDb = new JavaDB();
        objDb.createDb(dbName);
        
        String newTable = "CREATE TABLE items (numberS int, "
            + "numberR int, numberA1 int, numberN int )";
        
        objDb.createTable(newTable, dbName);
        
    }
}
