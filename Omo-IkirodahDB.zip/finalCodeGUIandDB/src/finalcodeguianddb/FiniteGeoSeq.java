/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalcodeguianddb;

//imports
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


public class FiniteGeoSeq extends JFrame implements ActionListener
{
  //colors and fonts
  public static final Color BLUE__COLOR = new Color(0,166,204);
  public static final Font BIG__FONT = new Font("Caveat", Font.BOLD | Font.ITALIC, 40);
  public static final Font small__FONT = new Font("Caveat", Font.BOLD | Font.ITALIC, 20);
  
  //image
  private final URL WELCOME_PATH = getClass().getResource("proving-the-formula.jpg");
  private final ImageIcon IMAGE = new ImageIcon(new ImageIcon(WELCOME_PATH).getImage().getScaledInstance(600, 400,Image.SCALE_DEFAULT));
  
  //label
  private JLabel welcomneLabel;
  private JLabel imageLabel;
  private JLabel explain;
  private JLabel explain2;
  private JLabel explain3;
  
  //button
  private JButton exit;
  private JButton next;
  private JButton data;
  private JButton dataR;
  private JButton insert;
  
  //panels
  private JPanel buttonPanel;
  private JPanel explainPanel;
  
  public FiniteGeoSeq(){
    //frame basics
    super("Welcome Frame");
    this.setBounds(100,50,800,600);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.getContentPane().setBackground(BLUE__COLOR);
    
    //defining welcome label
    this.welcomneLabel = new JLabel("Welcome to osi's amazing app");
    welcomneLabel.setFont(BIG__FONT);
    welcomneLabel.setForeground(Color.WHITE);
    welcomneLabel.setBorder(BorderFactory.createEmptyBorder(0,75,0,75));
    
    //constructing image label
    this.imageLabel = new JLabel(IMAGE);
    imageLabel.setBorder(BorderFactory.createEmptyBorder(10,10,0,50));
    
    //explaning the function
    this.explainPanel = new JPanel();
    this.explain = new JLabel("this is an app that can calculate different values of a finite geometric sequence");
    explain.setFont(small__FONT);
    explain.setForeground(Color.BLACK);
    this.explain3 = new JLabel("data doesnt add values for r");
    explain3.setFont(small__FONT);
    explain3.setForeground(Color.BLACK);
    explainPanel.add(Box.createVerticalStrut(5));
    explainPanel.add(explain);
    explainPanel.add(Box.createVerticalStrut(10));
    explainPanel.add(explain3);
    explainPanel.setBorder(BorderFactory.createEmptyBorder(0,10,30,0));
    
    //constructing button
    this.exit = new JButton("exit");
    this.next = new JButton("next");
    this.data = new JButton("view data");
    this.dataR = new JButton("view data for R");
    this.insert = new JButton("insert");
    
    //activate button
    exit.addActionListener(this);
    next.addActionListener(this);
    data.addActionListener(this);
    dataR.addActionListener(this);
    insert.addActionListener(this);
    
    //constructing button panel
    this.buttonPanel = new JPanel();
    buttonPanel.add(Box.createVerticalStrut(70));
    buttonPanel.add(exit);
    buttonPanel.add(Box.createVerticalStrut(70));
    buttonPanel.add(next);
    buttonPanel.add(Box.createVerticalStrut(70));
    buttonPanel.add(data);
    buttonPanel.add(Box.createVerticalStrut(70));
    buttonPanel.add(dataR);
    buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS)); 
    buttonPanel.setOpaque(false);
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(0,0,0,50));
    
    //adding to frame
    this.add(imageLabel,BorderLayout.CENTER);
    this.add(welcomneLabel,BorderLayout.NORTH);
    this.add(buttonPanel,BorderLayout.EAST);
    this.add(explainPanel,BorderLayout.SOUTH);
    
//make frame visible
    this.setVisible(true);
  }
  
      
  public static void main(String[] args)
  {
    
    //actually running what i coded
    new FiniteGeoSeq();
  }
  
  
  //button commands
  public void actionPerformed(ActionEvent e){
    //finding out which button was pressed
    String command = e.getActionCommand();
    
    //checking which button pressed
    //exit button
    if (command.equals("exit")){
      this.dispose();
    }  
    //next button
    else if (command.equals("next")){
      this.dispose();
      new choice();
    }
    else if (command.equals("view data")){
      String dbName = "numbers";
      String tableName = "items";
      String[] columnNames = 
      {
        "numberS","numberR","numberA1","numberN"
      };
      new DisplayDB(dbName, tableName, columnNames);
    }
    else if (command.equals("view data for R")){
      String dbName = "numbersStoredforRlatest";
      String tableName = "storedThingforRLatest";
      String[] columnNames =
      {
        "num1", "num1Position", "num2", "num2position", "R"
      };
      new DisplayDBR(dbName, tableName, columnNames);
    }
  }
  
  
}
