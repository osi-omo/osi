/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalcodeguianddb;

//imports
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author osiom
 */
public class choice extends JFrame implements ActionListener
{
  //color and font 
  public static final Color BLUE__COLOR = new Color(0,166,204);
  public static final Font BIG__FONT = new Font("Caveat", Font.BOLD | Font.ITALIC, 40);
  
  //images
  private final URL WELCOME_PATH = getClass().getResource("Simage.jpg");
  private final ImageIcon IMAGEs = new ImageIcon(new ImageIcon(WELCOME_PATH).getImage().getScaledInstance(300, 200,Image.SCALE_DEFAULT));
  private final URL WELCOME_PATHn = getClass().getResource("nimage.jpg");
  private final ImageIcon IMAGEn = new ImageIcon(new ImageIcon(WELCOME_PATHn).getImage().getScaledInstance(300, 200,Image.SCALE_DEFAULT));
  private final URL WELCOME_PATHr = getClass().getResource("rimage.jpg");
  private final ImageIcon IMAGEr = new ImageIcon(new ImageIcon(WELCOME_PATHr).getImage().getScaledInstance(300, 200,Image.SCALE_DEFAULT));
  private final URL WELCOME_PATHa = getClass().getResource("aimge.jpg");
  private final ImageIcon IMAGEa = new ImageIcon(new ImageIcon(WELCOME_PATHa).getImage().getScaledInstance(300, 200,Image.SCALE_DEFAULT));
  
  //label
  private JLabel welcomneLabel;
  private JLabel imageLabelS;
  private JLabel imageS;
  private JLabel imageN;
  private JLabel imageR;
  private JLabel imageA;
  
  //button
  private JButton S;
  private JButton n;
  private JButton r;
  private JButton a;
  private JButton data;
  private JButton dataR;
  private JButton exit;
  private JButton home;
  
  //panel
  private JPanel sbuttonPanel;
  private JPanel nbuttonPanel;
  private JPanel rbuttonPanel;
  private JPanel abuttonPanel;
  private JPanel BasicButtonPanel;
  
  //actual code
  public choice(){
    //frame basics
    super("Welcome Frame");
    this.setBounds(100,50,700,600);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.getContentPane().setBackground(BLUE__COLOR);
    
    //asks user for value
    this.welcomneLabel = new JLabel("which value do you want to find ");
    welcomneLabel.setFont(BIG__FONT);
    welcomneLabel.setForeground(Color.WHITE);
    
    //constructing image labels
    this.imageR = new JLabel(IMAGEr);
    this.imageA= new JLabel(IMAGEa);
    this.imageS = new JLabel(IMAGEs);
    this.imageN= new JLabel(IMAGEn);
    
    //constructing sand n buttonpanel
    this.S = new JButton("S");
    this.S.add(imageS);
    S.addActionListener(this);
    this.sbuttonPanel = new JPanel();
    this.n = new JButton("n");
    n.addActionListener(this);
    this.n.add(imageN);
    sbuttonPanel.add(S);
    sbuttonPanel.add(Box.createHorizontalStrut(10));
    sbuttonPanel.add(n);
    sbuttonPanel.setLayout(new BoxLayout(sbuttonPanel, BoxLayout.X_AXIS));
    sbuttonPanel.setOpaque(false);
    sbuttonPanel.setBorder(BorderFactory.createEmptyBorder(0,5,250,0));
    
    //constructing a and r button panel
    this.a = new JButton("A1");
    this.a.add(imageA);
    a.addActionListener(this);
    this.abuttonPanel = new JPanel();
    this.r = new JButton("r");
    this.r.add(imageR);
    r.addActionListener(this);
    abuttonPanel.add(a);
    abuttonPanel.add(Box.createHorizontalStrut(10));
    abuttonPanel.add(r);
    abuttonPanel.setLayout(new BoxLayout(abuttonPanel, BoxLayout.X_AXIS));
    abuttonPanel.setOpaque(false);
    abuttonPanel.setBorder(BorderFactory.createEmptyBorder(200,5,0,0));
    
    //constructing exit and homebutton
    this.exit = new JButton("exit");
    exit.addActionListener(this);
    this.home = new JButton("home");
    home.addActionListener(this);
    this.data = new JButton("data");
    data.addActionListener(this);
    this.dataR = new JButton("data for R");
    dataR.addActionListener(this);
    
    //constructing home and exit button panel 
    this.BasicButtonPanel = new JPanel();  
    BasicButtonPanel.add(exit);
    BasicButtonPanel.add(home);
    BasicButtonPanel.add(data);
    BasicButtonPanel.add(dataR);
    
    //adding to frame
    this.add(welcomneLabel,BorderLayout.NORTH);
    this.add(sbuttonPanel,BorderLayout.WEST);
    this.add(abuttonPanel,BorderLayout.LINE_END);
    this.add(BasicButtonPanel,BorderLayout.SOUTH);
    
    //make frame visible
    this.setVisible(true);
  }
  
      
  public static void main(String[] args)
  {
     
     //makes code happen
    new choice();
  }
  public void actionPerformed(ActionEvent e){
    //finding out which button was pressed
    String command = e.getActionCommand();
    
    //checking which button pressed
    if (command.equals("S")){
      this.dispose();
      new inputForS();
    }  
    
    else if (command.equals("r")){
      this.dispose();
      new inputForR();
        
    }
    
    else if (command.equals("n")){
      this.dispose();
      new inputForN();
    }
    
    else if (command.equals("A1")){
      this.dispose();
      new inputForA1();
        
    }
    else if (command.equals("exit")){
      this.dispose();
        
    }
    else if (command.equals("home")){
      this.dispose();
      new FiniteGeoSeq();
    }
    else if (command.equals("data")){
      String dbName = "numbers";
      String tableName = "items";
      String[] columnNames = 
      {
        "numberS", "numberR", "numberA1", "numberN"
      };
      new DisplayDB(dbName, tableName, columnNames);
    }
    else if (command.equals("data for R")){
      String dbName = "numbersStoredforRlatest";
      String tableName = "storedThingforRLatest";
      String[] columnNames =
      {
        "num1", "num1Position", "num2", "num2position", "R"
      };
      new DisplayDBR(dbName, tableName, columnNames);
    }
  }
  
}

