/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalcodeguianddb;
import static finalcodeguianddb.choice.BLUE__COLOR;
import static finalcodeguianddb.inputForN.Turqoise;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
/**
 *
 * @author osiom
 */
public class inputForR extends JFrame implements ActionListener
{
 public static final Color Turqoise = new Color(9,203,184);
  public static final Color idk = new Color(254,190,2);
  public static final Font CAPTION_FONT = new Font("Pacifico", Font.BOLD,15);
  public final Font INSTUCTIONS_FONT = new Font("Pacifico", Font.BOLD,20);
  public static final Color PURPLE = new Color(9,203,184);
  
  private final URL WELCOME_PATH = getClass().getResource("rimage.jpg");
  private final ImageIcon IMAGE = new ImageIcon(new ImageIcon(WELCOME_PATH).getImage().getScaledInstance(600, 400,Image.SCALE_DEFAULT));
  
  private JLabel FirstNumPlace;
  private JLabel FirstNum;
  private JLabel SecondNumPlace;
  private JLabel SecondNum;
  private JLabel instructions;
  private JLabel instructions2;
 
  private JTextField FirstNumPlaceField;
  private JTextField FirstNumField;
  private JTextField SecondNumPlaceField;
  private JTextField SecondNumField;
   
  private JButton enter;
  private JButton back;
  private JButton home;
  private JButton displayData;
  private JLabel imageLabel;
  private JPanel inputPanel;
  private JPanel buttonPanel;
  private JPanel instructionsPanel;
  
  public inputForR(){
    super("Welcome Frame");
    this.setBounds(100,50,800,600);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.getContentPane().setBackground(BLUE__COLOR);
    
    this.imageLabel = new JLabel(IMAGE);
    imageLabel.setBorder(BorderFactory.createEmptyBorder(10,10,0,50));
    
    
    instructions = new JLabel("Please enter yout values solving for R: ", SwingConstants.CENTER);
    instructions.setFont(INSTUCTIONS_FONT);
    instructions2 = new JLabel("enter position in the sequence. eg. 1st = 1 ", SwingConstants.CENTER);
    instructions2.setFont(INSTUCTIONS_FONT);
    instructionsPanel = new JPanel();
    instructionsPanel.add(instructions);
    instructions.add(Box.createVerticalStrut(60));
    instructionsPanel.add(instructions2);
    instructionsPanel.setLayout(new BoxLayout(instructionsPanel, BoxLayout.Y_AXIS));
    
    
    
    FirstNum = new JLabel("first num: ");
    instructions.setFont(CAPTION_FONT);
    FirstNumPlace = new JLabel("position: ");
    FirstNumPlace.setFont(CAPTION_FONT);
    SecondNum = new JLabel("second num: ");
    SecondNum.setFont(CAPTION_FONT);
    SecondNumPlace = new JLabel("position: ");
    SecondNumPlace.setFont(CAPTION_FONT);
    
    //the character limit affects text feild size
    FirstNumField = new JTextField(10);
    FirstNumPlaceField = new JTextField(10);
    SecondNumField = new JTextField(10);
    SecondNumPlaceField = new JTextField(10);
    
    enter = new JButton("enter");
    enter.addActionListener(this);
    back = new JButton("back");
    back.addActionListener(this);
    home = new JButton("home");
    home.addActionListener(this);   
    displayData = new JButton("data");
    displayData.addActionListener(this);
    
    buttonPanel = new JPanel();
    buttonPanel.add(back);
    buttonPanel.add(home);
    buttonPanel.add(displayData);
    buttonPanel.setBackground(idk);
    
    //the order in wich you add to a container is the order inwhich components appear
    inputPanel = new JPanel();
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(FirstNum);
    inputPanel.add(FirstNumField);
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(FirstNumPlace);
    inputPanel.add(FirstNumPlaceField);
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(SecondNum);
    inputPanel.add(SecondNumField);
    inputPanel.add(Box.createVerticalStrut(60));
    inputPanel.add(SecondNumPlace);
    inputPanel.add(SecondNumPlaceField);
    inputPanel.add(Box.createVerticalStrut(20));
    inputPanel.add(enter);
    inputPanel.add(Box.createVerticalStrut(20));
    inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
    inputPanel.setBackground(Turqoise);
    
    
    this.add(instructionsPanel, BorderLayout.NORTH);
    this.add(inputPanel, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.add(imageLabel,BorderLayout.WEST);
    this.setVisible(true);
  }
  public static void main(String[] args)
  {
    new inputForR();
  }
  
  public void actionPerformed(ActionEvent e){
    String command = e.getActionCommand();
    double firstNum;
    double secondNum;
    double firstNumPlace;
    double secondNumPlace;
    String result;
        
    if (command.equals("back")){
      this.dispose();   
      new choice();
    }
    
    else if (command.equals("home")){
      this.dispose();
      new FiniteGeoSeq();   
    }
    
    else if (command.equals("data")){
      String dbName = "numbersStoredforRlatest";
      String tableName = "storedThingforRLatest";
      String[] columnNames =
      {
        "num1", "num1Position", "num2", "num2position", "R"
      };
      new DisplayDBR(dbName, tableName, columnNames);
    }
    
    else if (command.equals("enter")){
      this.dispose();
      
      command = e.getActionCommand();
      String dbName = "numbersStoredforRlatest";
      String tableName = "storedThingforRLatest";
      String[] columnNames =
      {
        "num1", "num1Position", "num2", "num2position", "R"
      };
      //insert query
      JavaDB objDb = new JavaDB(dbName);
      Connection myDbConn = objDb.getDbConn();

      String dbQuery = "INSERT INTO storedThingforRLatest VALUES(?,?,?,?,?)";
      
      try
      {
        firstNum = Double.parseDouble(FirstNumField.getText());
        secondNum = Double.parseDouble(SecondNumField.getText());
        firstNumPlace = Double.parseDouble(FirstNumPlaceField.getText());
        secondNumPlace = Double.parseDouble(SecondNumPlaceField.getText());
      
        math objectadd = new math(firstNum, secondNum,firstNumPlace,secondNumPlace);
        result = objectadd.SolveR();
        
        if (result.equalsIgnoreCase( "ÿour equation is illogical")){
          this.dispose( );
          new error("your answer dont exist twin",4);
        }
        else{
          try
          {
            PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
            ps.setString(1, String.valueOf(firstNum));
            ps.setString(2, String.valueOf(firstNumPlace));
            ps.setString(3, String.valueOf(secondNum));
            ps.setString(4, String.valueOf(secondNumPlace));
            ps.setString(5, result);
            System.out.println(result);
            ps.executeUpdate();
            System.out.println("Data inserted succesfully");

            this.toFront();
          }
          catch (NumberFormatException nfe)
          {
            System.out.println("Enter digits for price");
          }
          catch (SQLException se)
          {
            System.out.println("Error inserting data");
          }
          new output(result,4);
        }
        
      }
      catch (NumberFormatException lol)
      {
        //lol.getStackTrace();//returns exception stack trace
        //System.exit(0);
        //inform the user
        new warning("please enter only numbers twin",4);
      }
      
    }
  }
}
