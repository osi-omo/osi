/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalcodeguianddb;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;


public class DisplayDBR extends JFrame implements ActionListener
{
  private JButton backButton;
  private JPanel buttonPanel;
  
  private ArrayList<ArrayList<String>> dataList;
  private Object[][] data;
  private JTable dbTable;
  private JScrollPane scrollTable;
  private JTableHeader header;
  private TableColumn column;
  
  public DisplayDBR(String dbName, String tableName, String[] tableHeaders)
  {
    super("display");
    this.setBounds(100,50,800,600);
    this.getContentPane().setBackground(Color.LIGHT_GRAY);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    
    JavaDB dbObj = new JavaDB(dbName);
    dataList = dbObj.getData(tableName,tableHeaders);
    data = dbObj.to2dArray(dataList);
    dbObj.closeDbConn();
    
    dbTable = new JTable(data,tableHeaders);
    dbTable.setGridColor(Color.RED);
    dbTable.setBackground(Color.GREEN);
    dbTable.setFont(new Font("Arial",Font.BOLD,20));
    
    header = dbTable.getTableHeader();
    header.setBackground(Color.MAGENTA);
    header.setForeground(Color.WHITE);
    header.setFont(new Font("Arial",Font.BOLD,20));
    
    dbTable.setRowHeight(30);
    
    column = dbTable.getColumnModel().getColumn(0);
    column.setPreferredWidth(50);
    column = dbTable.getColumnModel().getColumn(1);
    column.setPreferredWidth(100);
    column = dbTable.getColumnModel().getColumn(2);
    column.setPreferredWidth(50);
    column = dbTable.getColumnModel().getColumn(3);
    column.setPreferredWidth(100);
    column = dbTable.getColumnModel().getColumn(4);
    column.setPreferredWidth(200);
    
    scrollTable = new JScrollPane();
    scrollTable.getViewport().add(dbTable);
    dbTable.setFillsViewportHeight(true);
    
    this.backButton = new JButton("back");
    backButton.addActionListener(this);
    this.buttonPanel = new JPanel();
    buttonPanel.setBackground(Color.DARK_GRAY);
    buttonPanel.add(backButton);
    
    
    this.add(buttonPanel,BorderLayout.NORTH);
    this.add(scrollTable,BorderLayout.CENTER);
    
    this.setVisible(true);
  }
  
  public static void main(String[] args)
  {
    String dbName = "numbersStoredforRlatest";
      String tableName = "storedThingforRLatest";
      String[] columnNames =
      {
        "num1", "num1Position", "num2", "num2position", "R"
      };
      
    new DisplayDBR(dbName, tableName, columnNames);
  }
      
  public void actionPerformed(ActionEvent e)
  {
    String command = e.getActionCommand();
    if(command.equals("back"))
    {
      this.dispose();
    }
  }
}
