/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalcodeguianddb;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author osiom
 */
public class warning extends JFrame implements ActionListener
{
  private Color WARNING_COLOR = new Color(238,76,68);
  private Font WARNING_FONT = new Font("Arial", Font.BOLD,40);
      
  private final URL WELCOME_PATH = getClass().getResource("warn.jpeg");
  private final ImageIcon IMAGE = new ImageIcon(new ImageIcon(WELCOME_PATH).getImage().getScaledInstance(360, 240,Image.SCALE_DEFAULT));
  
  private JLabel warningLabel;
  private JButton okay;
  private JLabel imageLabel;
  
  private JPanel warningPanel;
  private JPanel buttonPanel;
  private static int tab;
  
  public warning(String warningMessage, int tab){
    super("Output");
    this.setBounds(300,300,800,500);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.getContentPane().setBackground(WARNING_COLOR);
    this.tab = tab;
    
    warningLabel = new JLabel("only numbers twin",SwingConstants.CENTER);
    warningLabel.setFont(WARNING_FONT);
    
    this.imageLabel = new JLabel(IMAGE);
    imageLabel.setBorder(BorderFactory.createEmptyBorder(10,10,0,50));
    
    okay = new JButton("OK");
    okay.addActionListener(this);
    
    buttonPanel = new JPanel();
    buttonPanel.add(okay);
    
    warningPanel = new JPanel();
    warningPanel.add(warningLabel);
    
    this.add(warningLabel,BorderLayout.NORTH);
    this.add(buttonPanel,BorderLayout.SOUTH);
    this.add(imageLabel,BorderLayout.CENTER);
    this.setVisible(true);
        
  }
  public void actionPerformed(ActionEvent e){
    String command = e.getActionCommand();
    
    if (command.equals("OK")){
      this.dispose();
      if (this.tab == 1){
        new inputForN();
      }
      if (this.tab == 2){
        new inputForA1();
      }
      if (this.tab == 3){
        new inputForS();
      }
      if (this.tab == 4){
        new inputForR();
      }
    }
  }
}
